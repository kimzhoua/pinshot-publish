package com.example.pinshot;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;

/** 贴图窗口的手势：拖动 / 双指缩放 / 长按切换半透明 */
class PinTouch implements View.OnTouchListener {

    private final Context ctx;
    private final PinService.PinWindow pw;
    private final WindowManager wm;
    private final int screenW;
    private final int screenH;
    private final Runnable onClose;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private long lastTapTime = 0L;

    private float downX, downY;
    private int startX, startY;
    private int startW, startH;
    private float startDist;
    private boolean moved;
    private long downTime;
    private Runnable longPressRunnable;

    PinTouch(Context ctx, PinService.PinWindow pw, WindowManager wm,
             int screenW, int screenH, Runnable onClose) {
        this.ctx = ctx;
        this.pw = pw;
        this.wm = wm;
        this.screenW = screenW;
        this.screenH = screenH;
        this.onClose = onClose;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = event.getRawX();
                downY = event.getRawY();
                startX = pw.lp.x;
                startY = pw.lp.y;
                startW = pw.lp.width;
                startH = pw.lp.height;
                startDist = 0f;
                moved = false;
                downTime = System.currentTimeMillis();
                scheduleLongPress();
                return true;

            case MotionEvent.ACTION_POINTER_DOWN:
                if (event.getPointerCount() >= 2) {
                    cancelLongPress();
                    startDist = spacing(event);
                    startW = pw.lp.width;
                    startH = pw.lp.height;
                    moved = true;
                }
                return true;

            case MotionEvent.ACTION_MOVE: {
                float dx = event.getRawX() - downX;
                float dy = event.getRawY() - downY;
                if (Math.abs(dx) > dp(5) || Math.abs(dy) > dp(5)) {
                    if (!moved) cancelLongPress();
                    moved = true;
                }

                if (event.getPointerCount() >= 2 && startDist > 0f) {
                    float dist = spacing(event);
                    float ratio = dist / startDist;
                    int w = (int) (startW * ratio);
                    int h = (int) (startH * ratio);
                    int minW = dp(20);
                    int maxW = (int) (screenW * 1.6f);
                    w = Math.max(minW, Math.min(maxW, w));
                    h = (int) (w * (float) startH / Math.max(1, startW));
                    if (h > screenH * 1.6f) {
                        h = (int) (screenH * 1.6f);
                        w = (int) (h * (float) startW / Math.max(1, startH));
                    }
                    pw.lp.width = w;
                    pw.lp.height = h;
                } else if (moved) {
                    pw.lp.x = Math.max(0, Math.min(screenW - pw.lp.width, startX + (int) dx));
                    pw.lp.y = Math.max(0, Math.min(screenH - pw.lp.height, startY + (int) dy));
                }

                try {
                    wm.updateViewLayout(v, pw.lp);
                } catch (Exception ignored) {
                }
                return true;
            }

            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                cancelLongPress();
                if (!moved && System.currentTimeMillis() - downTime < 500) {
                    long now = System.currentTimeMillis();
                    if (now - lastTapTime < 350) {
                        // 双击：关闭这张贴图
                        lastTapTime = 0L;
                        v.animate().alpha(0f).scaleX(0.92f).scaleY(0.92f)
                                .setDuration(140)
                                .withEndAction(onClose)
                                .start();
                    } else {
                        lastTapTime = now;
                        // 单击：轻微闪一下表示已选中
                        v.animate().alpha(0.92f).setDuration(120).withEndAction(new Runnable() {
                            @Override
                            public void run() {
                                v.animate().alpha(pw.alpha).setDuration(120).start();
                            }
                        }).start();
                    }
                }
                return true;

            default:
                return true;
        }
    }

    private void scheduleLongPress() {
        cancelLongPress();
        longPressRunnable = new Runnable() {
            @Override
            public void run() {
                // 长按：不透明 → 85% → 70% → 55% → 不透明
                if (pw.alpha > 0.9f) {
                    pw.alpha = 0.85f;
                } else if (pw.alpha > 0.75f) {
                    pw.alpha = 0.70f;
                } else if (pw.alpha > 0.6f) {
                    pw.alpha = 0.55f;
                } else {
                    pw.alpha = 1f;
                }
                pw.container.setAlpha(pw.alpha);
                pw.container.performHapticFeedback(
                        android.view.HapticFeedbackConstants.LONG_PRESS);
            }
        };
        handler.postDelayed(longPressRunnable, 500);
    }

    private void cancelLongPress() {
        if (longPressRunnable != null) {
            handler.removeCallbacks(longPressRunnable);
            longPressRunnable = null;
        }
    }

    private float spacing(MotionEvent event) {
        if (event.getPointerCount() < 2) return 0f;
        float x = event.getX(0) - event.getX(1);
        float y = event.getY(0) - event.getY(1);
        return (float) Math.sqrt(x * x + y * y);
    }

    private int dp(int v) {
        return Math.round(v * ctx.getResources().getDisplayMetrics().density);
    }
}
