package com.example.pinshot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;

/**
 * 仅用于满足 Android 14+ 的前台服务要求：
 * 调用 MediaProjection 前必须先有一个 mediaProjection 类型的前台服务在跑。
 */
public class ProjectionService extends Service {

    static final String CHANNEL = "pinshot_projection";
    static final int ID = 2048;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            NotificationChannel ch = new NotificationChannel(CHANNEL, "截屏",
                    NotificationManager.IMPORTANCE_MIN);
            nm.createNotificationChannel(ch);
        }
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL)
                : new Notification.Builder(this);
        b.setContentTitle("正在截取屏幕")
                .setContentText("截图完成后会自动关闭")
                .setSmallIcon(android.R.drawable.ic_menu_camera)
                .setOngoing(true);
        startForeground(ID, b.build());
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
