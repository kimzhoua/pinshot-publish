package com.example.pinshot;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Point;
import android.graphics.drawable.GradientDrawable;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;

/**
 * 一键截屏：请求录屏权限 → 截取当前屏幕 → 预览 → 「贴图」或「保存到相册」。
 */
public class CaptureActivity extends Activity {

    private static final int REQ_CAPTURE = 3001;

    private CropView preview;
    private TextView tip;
    private Bitmap shot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildUi();
        requestCapture();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF0C0F14);
        root.setPadding(dp(12), dp(10), dp(12), dp(10));

        TextView head = new TextView(this);
        head.setText("区域截图");
        head.setTextSize(15);
        head.setTextColor(Color.WHITE);
        head.setGravity(Gravity.CENTER);
        head.setPadding(0, dp(6), 0, dp(8));
        root.addView(head);

        preview = new CropView(this);
        root.addView(preview, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        tip = new TextView(this);
        tip.setText("正在截取屏幕…");
        tip.setTextSize(12);
        tip.setTextColor(0xFF8D97A8);
        tip.setGravity(Gravity.CENTER);
        tip.setPadding(0, dp(8), 0, dp(6));
        root.addView(tip);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);

        bar.addView(barButton("贴图", 0xFF5B7BF7, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pinCurrent();
            }
        }));
        bar.addView(barButton("保存到相册", 0xFF2C3444, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveCurrent();
            }
        }));
        bar.addView(barButton("取消", 0xFF2C3444, new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        }));
        root.addView(bar);

        setContentView(root);
    }

    private TextView barButton(String text, int bgColor, View.OnClickListener l) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(14);
        tv.setTextColor(Color.WHITE);
        tv.setGravity(Gravity.CENTER);
        tv.setPadding(dp(12), dp(11), dp(12), dp(11));
        tv.setBackground(rounded(bgColor, 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(5), 0, dp(5), 0);
        tv.setLayoutParams(lp);
        tv.setOnClickListener(l);
        return tv;
    }

    // ---------------- 截屏 ----------------

    private void requestCapture() {
        MediaProjectionManager mpm =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        if (mpm == null) {
            tip.setText("系统不支持截屏");
            return;
        }
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            tip.setText("已取消截屏");
            finish();
            return;
        }
        // Android 14+ 要求先跑 mediaProjection 类型的前台服务
        if (Build.VERSION.SDK_INT >= 26) {
            Intent svc = new Intent(this, ProjectionService.class);
            startForegroundService(svc);
        } else {
            startService(svc());
        }
        final Intent resultData = data;
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                capture(resultData);
            }
        }, 220);
        tip.setText("正在截取屏幕…");
    }

    private Intent svc() {
        return new Intent(this, ProjectionService.class);
    }

    private void capture(Intent data) {
        MediaProjectionManager mpm =
                (MediaProjectionManager) getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        final MediaProjection projection = mpm.getMediaProjection(RESULT_OK, data);
        if (projection == null) {
            tip.setText("截屏失败，请重试");
            stopProjectionService();
            return;
        }

        Point size = realScreenSize();
        final int w = size.x;
        final int h = size.y;
        final ImageReader reader = ImageReader.newInstance(
                w, h, PixelFormat.RGBA_8888, 2);
        final VirtualDisplay display = projection.createVirtualDisplay(
                "pinshot-capture", w, h,
                getResources().getDisplayMetrics().densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.getSurface(), null, null);

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                Bitmap bmp = null;
                Image image = null;
                try {
                    image = reader.acquireLatestImage();
                    if (image != null) {
                        Image.Plane plane = image.getPlanes()[0];
                        ByteBuffer buffer = plane.getBuffer();
                        int pixelStride = plane.getPixelStride();
                        int rowStride = plane.getRowStride();
                        int rowPadding = rowStride - pixelStride * w;
                        int bmpW = w + rowPadding / pixelStride;
                        Bitmap raw = Bitmap.createBitmap(bmpW, h, Bitmap.Config.ARGB_8888);
                        raw.copyPixelsFromBuffer(buffer);
                        bmp = Bitmap.createBitmap(raw, 0, 0, w, h);
                        if (bmp != raw) raw.recycle();
                    }
                } catch (Exception e) {
                    bmp = null;
                } finally {
                    if (image != null) image.close();
                    try {
                        display.release();
                    } catch (Exception ignored) {
                    }
                    try {
                        reader.close();
                    } catch (Exception ignored) {
                    }
                    try {
                        projection.stop();
                    } catch (Exception ignored) {
                    }
                    stopProjectionService();
                }

                if (bmp == null) {
                    tip.setText("截屏失败，请重试");
                    return;
                }
                shot = bmp;
                preview.setBitmap(bmp);
                tip.setText("拖动边角调整截图区域，然后选择下面的操作");
            }
        }, 900);
    }

    private void stopProjectionService() {
        try {
            stopService(new Intent(this, ProjectionService.class));
        } catch (Exception ignored) {
        }
    }

    private Point realScreenSize() {
        WindowManager wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        Point p = new Point();
        if (wm != null) {
            if (Build.VERSION.SDK_INT >= 30) {
                android.view.WindowMetrics metrics = wm.getMaximumWindowMetrics();
                p.set(metrics.getBounds().width(), metrics.getBounds().height());
            } else {
                DisplayMetrics dm = new DisplayMetrics();
                wm.getDefaultDisplay().getRealMetrics(dm);
                p.set(dm.widthPixels, dm.heightPixels);
            }
        } else {
            DisplayMetrics dm = getResources().getDisplayMetrics();
            p.set(dm.widthPixels, dm.heightPixels);
        }
        return p;
    }

    // ---------------- 两个动作 ----------------

    private Bitmap cropped() {
        if (shot == null) return null;
        try {
            return preview.crop();
        } catch (Exception e) {
            return shot;
        }
    }

    private void pinCurrent() {
        Bitmap cropBmp = cropped();
        if (cropBmp == null) {
            toast("还没有截到图");
            return;
        }
        if (!Settings.canDrawOverlays(this)) {
            toast("需要「显示在其他应用上层」权限，去设置里打开");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        File f = new File(getCacheDir(), "capture.png");
        try (FileOutputStream out = new FileOutputStream(f)) {
            cropBmp.compress(Bitmap.CompressFormat.PNG, 100, out);
        } catch (Exception e) {
            toast("保存临时文件失败");
            return;
        }
        Intent pi = new Intent(this, PinService.class);
        pi.setAction(PinService.ACTION_PIN_PATH);
        pi.putExtra(PinService.EXTRA_PATH, f.getAbsolutePath());
        // 原位置贴图：把选框在屏幕上的实际坐标和尺寸一起传过去
        android.graphics.Rect r = preview.selectionOnScreen();
        pi.putExtra(PinService.EXTRA_X, r.left);
        pi.putExtra(PinService.EXTRA_Y, r.top);
        pi.putExtra(PinService.EXTRA_W, r.width());
        pi.putExtra(PinService.EXTRA_H, r.height());
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(pi);
        } else {
            startService(pi);
        }
        toast("已按原位置贴到屏幕上");
        finish();
    }

    private void saveCurrent() {
        Bitmap cropBmp = cropped();
        if (cropBmp == null) {
            toast("还没有截到图");
            return;
        }
        try {
            String name = "截图_" + System.currentTimeMillis() + ".png";
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/截图贴图");
                Uri target = getContentResolver()
                        .insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (target == null) {
                    toast("保存失败");
                    return;
                }
                try (OutputStream out = getContentResolver().openOutputStream(target)) {
                    cropBmp.compress(Bitmap.CompressFormat.PNG, 100, out);
                }
                toast("已保存到相册：Pictures/截图贴图");
            } else {
                MediaStore.Images.Media.insertImage(getContentResolver(), cropBmp, name, "截图贴图");
                toast("已保存到相册");
            }
            finish();
        } catch (Exception e) {
            toast("保存失败：" + e.getMessage());
        }
    }

    // ---------------- 工具 ----------------

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    protected void onDestroy() {
        stopProjectionService();
        if (shot != null) shot.recycle();
        super.onDestroy();
    }
}
