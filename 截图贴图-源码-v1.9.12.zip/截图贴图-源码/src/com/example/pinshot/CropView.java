package com.example.pinshot;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * 区域截图的选区控件：
 *   框内拖动＝移动选区，拖四个角＝缩放选区，在框外按下拖动＝重新框选
 */
public class CropView extends View {

    private Bitmap bitmap;
    private final Matrix matrix = new Matrix();
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dimPaint = new Paint();
    private final RectF sel = new RectF();
    private final RectF imageRect = new RectF();
    private float scale = 1f;

    private static final int NONE = 0, MOVE = 1, NEW = 2, TL = 3, TR = 4, BL = 5, BR = 6;
    private int mode = NONE;
    private float downX, downY;
    private RectF startSel = new RectF();

    public CropView(Context c) {
        super(c);
        init();
    }

    public CropView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        dimPaint.setColor(0xB3000000);
    }

    public void setBitmap(Bitmap bmp) {
        this.bitmap = bmp;
        layoutBitmap();
        invalidate();
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    private void layoutBitmap() {
        if (bitmap == null || getWidth() == 0 || getHeight() == 0) return;
        float sw = getWidth() / (float) bitmap.getWidth();
        float sh = getHeight() / (float) bitmap.getHeight();
        scale = Math.min(sw, sh);
        float dw = bitmap.getWidth() * scale;
        float dh = bitmap.getHeight() * scale;
        float left = (getWidth() - dw) / 2f;
        float top = (getHeight() - dh) / 2f;
        imageRect.set(left, top, left + dw, top + dh);
        matrix.reset();
        matrix.setScale(scale, scale);
        matrix.postTranslate(left, top);
        // 默认整个画面都被选中
        sel.set(imageRect);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        layoutBitmap();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (bitmap == null) return;
        canvas.drawBitmap(bitmap, matrix, paint);

        // 选区外的蒙层
        canvas.drawRect(0, 0, getWidth(), sel.top, dimPaint);
        canvas.drawRect(0, sel.bottom, getWidth(), getHeight(), dimPaint);
        canvas.drawRect(0, sel.top, sel.left, sel.bottom, dimPaint);
        canvas.drawRect(sel.right, sel.top, getWidth(), sel.bottom, dimPaint);

        // 边框
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(dp(1.5f));
        paint.setColor(0xFF5B7BF7);
        canvas.drawRect(sel, paint);

        // 四个角
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        float r = dp(6f);
        canvas.drawCircle(sel.left, sel.top, r, paint);
        canvas.drawCircle(sel.right, sel.top, r, paint);
        canvas.drawCircle(sel.left, sel.bottom, r, paint);
        canvas.drawCircle(sel.right, sel.bottom, r, paint);

        // 尺寸提示
        paint.setColor(0xFFFFFFFF);
        paint.setTextSize(dp(11f));
        paint.setStyle(Paint.Style.FILL);
        String size = cropWidth() + " × " + cropHeight();
        canvas.drawText(size, sel.left + dp(6f), Math.max(dp(14f), sel.top - dp(6f)), paint);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (bitmap == null) return false;
        float x = e.getX(), y = e.getY();

        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = x;
                downY = y;
                startSel.set(sel);
                mode = hitTest(x, y);
                if (mode == NONE) {
                    mode = NEW;
                    sel.set(x, y, x, y);
                }
                invalidate();
                return true;

            case MotionEvent.ACTION_MOVE: {
                float dx = x - downX;
                float dy = y - downY;
                if (mode == MOVE) {
                    sel.left = startSel.left + dx;
                    sel.top = startSel.top + dy;
                    sel.right = startSel.right + dx;
                    sel.bottom = startSel.bottom + dy;
                    keepInside(true);
                } else if (mode == NEW) {
                    sel.set(Math.min(downX, x), Math.min(downY, y),
                            Math.max(downX, x), Math.max(downY, y));
                    keepInside(false);
                } else {
                    if (mode == TL || mode == BL) sel.left = x;
                    if (mode == TR || mode == BR) sel.right = x;
                    if (mode == TL || mode == TR) sel.top = y;
                    if (mode == BL || mode == BR) sel.bottom = y;
                    if (sel.left > sel.right) {
                        float t = sel.left; sel.left = sel.right; sel.right = t;
                    }
                    if (sel.top > sel.bottom) {
                        float t = sel.top; sel.top = sel.bottom; sel.bottom = t;
                    }
                    keepInside(false);
                }
                invalidate();
                return true;
            }

            case MotionEvent.ACTION_UP:
                if (sel.width() < dp(24) || sel.height() < dp(24)) {
                    sel.set(imageRect);
                }
                invalidate();
                return true;
        }
        return true;
    }

    /** 判断按在哪个区域 */
    private int hitTest(float x, float y) {
        float t = dp(26);
        if (near(x, y, sel.left, sel.top, t)) return TL;
        if (near(x, y, sel.right, sel.top, t)) return TR;
        if (near(x, y, sel.left, sel.bottom, t)) return BL;
        if (near(x, y, sel.right, sel.bottom, t)) return BR;
        if (x > sel.left && x < sel.right && y > sel.top && y < sel.bottom) return MOVE;
        return NONE;
    }

    private boolean near(float x, float y, float cx, float cy, float t) {
        return Math.abs(x - cx) < t && Math.abs(y - cy) < t;
    }

    private void keepInside(boolean keepSize) {
        float minSize = dp(24);
        if (sel.left < imageRect.left) {
            if (keepSize) sel.offset(imageRect.left - sel.left, 0);
            else sel.left = imageRect.left;
        }
        if (sel.top < imageRect.top) {
            if (keepSize) sel.offset(0, imageRect.top - sel.top);
            else sel.top = imageRect.top;
        }
        if (sel.right > imageRect.right) {
            if (keepSize) sel.offset(imageRect.right - sel.right, 0);
            else sel.right = imageRect.right;
        }
        if (sel.bottom > imageRect.bottom) {
            if (keepSize) sel.offset(0, imageRect.bottom - sel.bottom);
            else sel.bottom = imageRect.bottom;
        }
        if (sel.width() < minSize) sel.right = sel.left + minSize;
        if (sel.height() < minSize) sel.bottom = sel.top + minSize;
    }

    public int cropWidth() {
        return Math.max(1, Math.round(sel.width() / scale));
    }

    public int cropHeight() {
        return Math.max(1, Math.round(sel.height() / scale));
    }

    /** 按当前选区裁剪出图片；选区等于全图时返回原图 */
    public Bitmap crop() {
        if (bitmap == null) return null;
        int w = bitmap.getWidth(), h = bitmap.getHeight();
        RectF r = new RectF(sel);
        r.intersect(imageRect);
        int x = Math.round((r.left - imageRect.left) / scale);
        int y = Math.round((r.top - imageRect.top) / scale);
        int cw = Math.round(r.width() / scale);
        int ch = Math.round(r.height() / scale);
        x = Math.max(0, Math.min(w - 1, x));
        y = Math.max(0, Math.min(h - 1, y));
        cw = Math.max(1, Math.min(w - x, cw));
        ch = Math.max(1, Math.min(h - y, ch));
        if (x == 0 && y == 0 && cw == w && ch == h) return bitmap;
        return Bitmap.createBitmap(bitmap, x, y, cw, ch);
    }

    /** 选区在屏幕上的实际像素矩形（用于“原位置贴图”） */
    public android.graphics.Rect selectionOnScreen() {
        int[] loc = new int[2];
        getLocationOnScreen(loc);
        android.graphics.Rect r = new android.graphics.Rect();
        r.left = loc[0] + Math.round(sel.left);
        r.top = loc[1] + Math.round(sel.top);
        r.right = loc[0] + Math.round(sel.right);
        r.bottom = loc[1] + Math.round(sel.bottom);
        return r;
    }

    private float dp(float v) {
        return v * getResources().getDisplayMetrics().density;
    }
}
