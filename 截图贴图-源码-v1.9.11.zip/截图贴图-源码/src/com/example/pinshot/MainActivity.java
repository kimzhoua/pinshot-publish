package com.example.pinshot;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 截图贴图 · 主界面
 *
 * 用法：先授予「悬浮窗」权限 → 打开悬浮球 → 之后截图，点悬浮球即可把最新截图钉在屏幕上。
 */
public class MainActivity extends Activity {

    static final String PREF = "pinshot";
    private static final int REQ_MEDIA = 1001;
    private static final int REQ_NOTIFY = 1002;

    private TextView statusText;
    private OtaManager otaManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        otaManager = new OtaManager(this);
        buildUi();
    }

    @Override
    protected void onDestroy() {
        if (otaManager != null) otaManager.release();
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshState();
    }

    private void refreshState() {
        boolean overlayOk = Settings.canDrawOverlays(this);
        boolean running = getSharedPreferences(PREF, MODE_PRIVATE).getBoolean("ball_on", false);
        statusText.setText(overlayOk
                ? (running ? "悬浮球已开启：截图后点悬浮球即可贴图"
                           : "权限已就绪。可以直接「钉住最新截图」，也可以开启悬浮球随时贴图")
                : "还差一步：需要授予「显示在其他应用上层」权限");
        statusText.setTextColor(overlayOk ? 0xFF1F7A3D : 0xFFC62828);
    }

    private void buildUi() {
        android.widget.ScrollView scrollRoot = new android.widget.ScrollView(this);
        scrollRoot.setBackgroundColor(0xFFF6F7FB);
        scrollRoot.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF6F7FB);
        int pad = dp(20);
        root.setPadding(pad, dp(28), pad, dp(32));

        TextView title = new TextView(this);
        title.setText("截图贴图");
        title.setTextSize(24);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFF1B2230);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("把截图钉在屏幕上，随时对照、复制、核对内容");
        sub.setTextSize(13);
        sub.setTextColor(0xFF6B7482);
        sub.setPadding(0, dp(6), 0, dp(16));
        root.addView(sub);

        statusText = new TextView(this);
        statusText.setTextSize(14);
        statusText.setPadding(dp(14), dp(14), dp(14), dp(14));
        statusText.setBackground(roundedColor(0xFFFFFFFF, 14));
        root.addView(statusText, matchWrap());

        root.addView(button("① 授予悬浮窗权限", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Settings.canDrawOverlays(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "权限已授予", Toast.LENGTH_SHORT).show();
                } else {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                }
            }
        }));

        root.addView(button("② 开启 / 关闭悬浮球（可选）", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "请先授予悬浮窗权限", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent svc = new Intent(MainActivity.this, PinService.class);
                boolean running = getSharedPreferences(PREF, MODE_PRIVATE)
                        .getBoolean("ball_on", false);
                if (running) {
                    svc.setAction(PinService.ACTION_STOP);
                } else {
                    ensurePermissions();
                    svc.setAction(PinService.ACTION_START);
                }
                startServiceCompat(svc);
                v.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        refreshState();
                    }
                }, 400);
            }
        }));

        root.addView(button("立即截屏并贴图（可加到状态栏）", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CaptureActivity.class));
            }
        }));

        root.addView(button("③ 钉住最新截图", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendAction(PinService.ACTION_PIN_LATEST);
            }
        }));

        root.addView(button("添加到状态栏快捷开关", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addQuickTile();
            }
        }));

        root.addView(button("从最近截图里选一张贴图", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ScreenshotPickerActivity.class));
            }
        }));

        root.addView(button("从相册选一张图贴图", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.setType("image/*");
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(pick, 2001);
            }
        }));

        root.addView(button("关闭屏幕上所有贴图", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendAction(PinService.ACTION_CLEAR);
            }
        }));

        // 设置入口：次要选项统一收进设置面板
        root.addView(button("设置", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettings();
            }
        }));

        TextView tips = new TextView(this);
        tips.setText("提示\n"
                + "· 贴图后：单指拖动移动，双指捏合缩放，长按切换半透明，双击关闭。\n"
                + "· 悬浮球点一下＝钉住最新截图，长按＝关闭悬浮球。\n"
                + "· 更多开关（边框阴影、放大、快捷开关、检查更新）在「设置」里。");
        tips.setTextSize(12);
        tips.setTextColor(0xFF6B7482);
        tips.setPadding(0, dp(18), 0, 0);
        root.addView(tips);

        // 内容较多，放进可滚动容器，避免底部按钮看不到
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFFF6F7FB);
        scroll.addView(root, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
    }

    private void sendAction(String action) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先授予悬浮窗权限", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent svc = new Intent(this, PinService.class);
        svc.setAction(action);
        startServiceCompat(svc);
    }

    // ============ 设置面板 ============

    private void showSettings() {
        LinearLayout panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(4), dp(8), dp(4), dp(4));

        panel.addView(sectionLabel("贴图外观"));
        panel.addView(switchRow("贴图显示边框与阴影", "frame_on", true,
                new Runnable() {
                    @Override
                    public void run() {
                        if (getSharedPreferences(PREF, MODE_PRIVATE).getBoolean("ball_on", false)) {
                            sendAction(PinService.ACTION_RESTYLE);
                        }
                    }
                }));
        panel.addView(switchRow("小截图放大到 72dp", "upscale_small", true, null));

        panel.addView(sectionLabel("快捷入口"));
        panel.addView(actionRow("添加到状态栏快捷开关", "去添加", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addQuickTile();
            }
        }));

        panel.addView(sectionLabel("关于"));
        panel.addView(actionRow("检查应用更新（当前 v" + versionName() + "）", "检查",
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        otaManager.checkUpdate(true);
                    }
                }));

        TextView ver = new TextView(this);
        ver.setText("截图贴图 v" + versionName() + "（" + versionCode() + "）");
        ver.setTextSize(11);
        ver.setTextColor(0xFF8A93A3);
        ver.setPadding(dp(6), dp(14), 0, 0);
        panel.addView(ver);

        new android.app.AlertDialog.Builder(this)
                .setTitle("设置")
                .setView(panel)
                .setPositiveButton("完成", null)
                .show();
    }

    private TextView sectionLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12);
        tv.setTextColor(0xFF8A93A3);
        tv.setPadding(dp(6), dp(14), dp(6), dp(6));
        return tv;
    }

    /** 一行「标题 + 开关」，开关改动立即写 SharedPreferences */
    private View switchRow(String label, final String key, boolean def, final Runnable after) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(8), dp(8), dp(8));
        row.setBackground(roundedColor(0xFFFFFFFF, 12));

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(14);
        tv.setTextColor(0xFF1B2230);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(tv);

        android.widget.Switch sw = new android.widget.Switch(this);
        sw.setChecked(getSharedPreferences(PREF, MODE_PRIVATE).getBoolean(key, def));
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                getSharedPreferences(PREF, MODE_PRIVATE).edit().putBoolean(key, checked).apply();
                if (after != null) after.run();
            }
        });
        row.addView(sw);
        return row;
    }

    /** 一行「标题 + 右侧动作文字」 */
    private View actionRow(String label, String action, View.OnClickListener listener) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(10), dp(14), dp(10));
        row.setBackground(roundedColor(0xFFFFFFFF, 12));

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(14);
        tv.setTextColor(0xFF1B2230);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(tv);

        TextView btn = new TextView(this);
        btn.setText(action);
        btn.setTextSize(14);
        btn.setTextColor(0xFF2F6BFF);
        btn.setPadding(dp(8), dp(2), dp(2), dp(2));
        btn.setOnClickListener(listener);
        row.addView(btn);
        return row;
    }

    private int versionCode() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    /** 引导用户把「截图贴图」加到下拉状态栏快捷开关 */
    private void addQuickTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            android.app.StatusBarManager sbm = getSystemService(android.app.StatusBarManager.class);
            if (sbm != null) {
                sbm.requestAddTileService(
                        new android.content.ComponentName(this, ScreenshotTileService.class),
                        "截图贴图", android.graphics.drawable.Icon.createWithResource(
                                this, R.drawable.ic_tile),
                        getMainExecutor(),
                        new java.util.function.Consumer<Integer>() {
                            @Override
                            public void accept(Integer result) {
                                Toast.makeText(MainActivity.this,
                                        result == android.app.StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED
                                                ? "已添加到状态栏快捷开关"
                                                : "请手动在状态栏编辑里添加「截图贴图」",
                                        Toast.LENGTH_LONG).show();
                            }
                        });
                return;
            }
        }
        Toast.makeText(this, "请下拉状态栏 → 点编辑按钮 → 把「截图贴图」拖进快捷开关",
                Toast.LENGTH_LONG).show();
    }

    private void startServiceCompat(Intent svc) {
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
    }

    private void ensurePermissions() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
            }
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_MEDIA);
            }
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_MEDIA);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2001 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先授予悬浮窗权限", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent svc = new Intent(this, PinService.class);
            svc.setAction(PinService.ACTION_PIN_URI);
            svc.setData(data.getData());
            startServiceCompat(svc);
        }
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    private TextView button(String text, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setAllCaps(false);
        btn.setTextSize(15);
        btn.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        lp.topMargin = dp(10);
        btn.setLayoutParams(lp);
        return btn;
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(4);
        return lp;
    }

    private android.graphics.drawable.GradientDrawable roundedColor(int color, int radiusDp) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }
}
