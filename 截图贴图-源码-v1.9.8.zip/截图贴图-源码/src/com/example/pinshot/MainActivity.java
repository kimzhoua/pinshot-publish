package com.example.pinshot;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 截图贴图 · 主界面
 *
 * 用法：先授予「悬浮窗」权限 → 打开悬浮球 → 之后截图，点悬浮球即可把最新截图钉在屏幕上。
 */
public class MainActivity extends Activity {

    static final String PREF = "pinshot";
    private static final int REQ_MEDIA = 1001;
    private static final int REQ_NOTIFY = 1002;

    private TextView statusText;
    private OtaManager otaManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        otaManager = new OtaManager(this);
        buildUi();
    }

    @Override
    protected void onDestroy() {
        if (otaManager != null) otaManager.release();
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshState();
    }

    private void refreshState() {
        boolean overlayOk = Settings.canDrawOverlays(this);
        boolean running = getSharedPreferences(PREF, MODE_PRIVATE).getBoolean("ball_on", false);
        statusText.setText(overlayOk
                ? (running ? "悬浮球已开启：截图后点悬浮球即可贴图"
                           : "权限已就绪。可以直接「钉住最新截图」，也可以开启悬浮球随时贴图")
                : "还差一步：需要授予「显示在其他应用上层」权限");
        statusText.setTextColor(overlayOk ? 0xFF1F7A3D : 0xFFC62828);
    }

    private void buildUi() {
        android.widget.ScrollView scrollRoot = new android.widget.ScrollView(this);
        scrollRoot.setBackgroundColor(0xFFF6F7FB);
        scrollRoot.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF6F7FB);
        int pad = dp(20);
        root.setPadding(pad, dp(28), pad, dp(32));

        TextView title = new TextView(this);
        title.setText("截图贴图");
        title.setTextSize(24);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFF1B2230);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("把截图钉在屏幕上，随时对照、复制、核对内容");
        sub.setTextSize(13);
        sub.setTextColor(0xFF6B7482);
        sub.setPadding(0, dp(6), 0, dp(16));
        root.addView(sub);

        statusText = new TextView(this);
        statusText.setTextSize(14);
        statusText.setPadding(dp(14), dp(14), dp(14), dp(14));
        statusText.setBackground(roundedColor(0xFFFFFFFF, 14));
        root.addView(statusText, matchWrap());

        root.addView(button("① 授予悬浮窗权限", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Settings.canDrawOverlays(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "权限已授予", Toast.LENGTH_SHORT).show();
                } else {
                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                            Uri.parse("package:" + getPackageName())));
                }
            }
        }));

        root.addView(button("② 开启 / 关闭悬浮球（可选）", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!Settings.canDrawOverlays(MainActivity.this)) {
                    Toast.makeText(MainActivity.this, "请先授予悬浮窗权限", Toast.LENGTH_SHORT).show();
                    return;
                }
                Intent svc = new Intent(MainActivity.this, PinService.class);
                boolean running = getSharedPreferences(PREF, MODE_PRIVATE)
                        .getBoolean("ball_on", false);
                if (running) {
                    svc.setAction(PinService.ACTION_STOP);
                } else {
                    ensurePermissions();
                    svc.setAction(PinService.ACTION_START);
                }
                startServiceCompat(svc);
                v.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        refreshState();
                    }
                }, 400);
            }
        }));

        root.addView(button("立即截屏并贴图（可加到状态栏）", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, CaptureActivity.class));
            }
        }));

        root.addView(button("③ 钉住最新截图", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendAction(PinService.ACTION_PIN_LATEST);
            }
        }));

        root.addView(button("添加到状态栏快捷开关", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addQuickTile();
            }
        }));

        root.addView(button("从最近截图里选一张贴图", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ScreenshotPickerActivity.class));
            }
        }));

        root.addView(button("从相册选一张图贴图", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                pick.setType("image/*");
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                startActivityForResult(pick, 2001);
            }
        }));

        root.addView(button("关闭屏幕上所有贴图", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendAction(PinService.ACTION_CLEAR);
            }
        }));

        // 设置：贴图是否显示白底边框与阴影
        LinearLayout frameRow = new LinearLayout(this);
        frameRow.setOrientation(LinearLayout.HORIZONTAL);
        frameRow.setGravity(Gravity.CENTER_VERTICAL);
        frameRow.setPadding(dp(14), dp(6), dp(6), dp(6));
        LinearLayout.LayoutParams frLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        frLp.topMargin = dp(12);
        frameRow.setLayoutParams(frLp);
        frameRow.setBackground(roundedColor(0xFFFFFFFF, 14));

        TextView frameLabel = new TextView(this);
        frameLabel.setText("贴图显示边框与阴影");
        frameLabel.setTextSize(14);
        frameLabel.setTextColor(0xFF1B2230);
        frameLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        frameRow.addView(frameLabel);

        final android.widget.Switch frameSwitch = new android.widget.Switch(this);
        frameSwitch.setChecked(getSharedPreferences(PREF, MODE_PRIVATE)
                .getBoolean("frame_on", true));
        frameSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                getSharedPreferences(PREF, MODE_PRIVATE).edit()
                        .putBoolean("frame_on", isChecked).apply();
                if (getSharedPreferences(PREF, MODE_PRIVATE).getBoolean("ball_on", false)) {
                    sendAction(PinService.ACTION_RESTYLE);
                }
            }
        });
        frameRow.addView(frameSwitch);
        root.addView(frameRow);

        // 设置：小截图是否放大到 72dp
        LinearLayout scaleRow = new LinearLayout(this);
        scaleRow.setOrientation(LinearLayout.HORIZONTAL);
        scaleRow.setGravity(Gravity.CENTER_VERTICAL);
        scaleRow.setPadding(dp(14), dp(6), dp(6), dp(6));
        LinearLayout.LayoutParams srLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        srLp.topMargin = dp(8);
        scaleRow.setLayoutParams(srLp);
        scaleRow.setBackground(roundedColor(0xFFFFFFFF, 14));

        TextView scaleLabel = new TextView(this);
        scaleLabel.setText("小截图放大到 72dp");
        scaleLabel.setTextSize(14);
        scaleLabel.setTextColor(0xFF1B2230);
        scaleLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        scaleRow.addView(scaleLabel);

        final android.widget.Switch scaleSwitch = new android.widget.Switch(this);
        scaleSwitch.setChecked(getSharedPreferences(PREF, MODE_PRIVATE)
                .getBoolean("upscale_small", true));
        scaleSwitch.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton buttonView, boolean isChecked) {
                getSharedPreferences(PREF, MODE_PRIVATE).edit()
                        .putBoolean("upscale_small", isChecked).apply();
            }
        });
        scaleRow.addView(scaleSwitch);
        root.addView(scaleRow);

        // 检查应用更新（读取 GitHub 上的签名清单）
        LinearLayout updateRow = new LinearLayout(this);
        updateRow.setOrientation(LinearLayout.HORIZONTAL);
        updateRow.setGravity(Gravity.CENTER_VERTICAL);
        updateRow.setPadding(dp(14), dp(6), dp(14), dp(6));
        LinearLayout.LayoutParams upLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        upLp.topMargin = dp(8);
        updateRow.setLayoutParams(upLp);
        updateRow.setBackground(roundedColor(0xFFFFFFFF, 14));

        TextView versionLabel = new TextView(this);
        versionLabel.setText("检查应用更新（当前 v" + versionName() + "）");
        versionLabel.setTextSize(14);
        versionLabel.setTextColor(0xFF1B2230);
        versionLabel.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        updateRow.addView(versionLabel);

        TextView updateBtn = new TextView(this);
        updateBtn.setText("检查");
        updateBtn.setTextSize(14);
        updateBtn.setTextColor(0xFF2F6BFF);
        updateBtn.setPadding(dp(10), dp(4), dp(2), dp(4));
        updateBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                otaManager.checkUpdate(true);
            }
        });
        updateRow.addView(updateBtn);
        root.addView(updateRow);

        TextView tips = new TextView(this);
        tips.setText("提示\n"
                + "· 贴图后：单指拖动移动位置，双指捏合可无限放大/缩小，长按切换半透明，双击关闭这张贴图。\n"
                + "· 不开悬浮球也能贴图：主界面「钉住最新截图」直接用。\n"
                + "· 悬浮球也可以拖动，点一下＝钉住最新截图，长按＝关闭悬浮球。\n"
                + "· 若「钉住最新截图」找不到图片，请允许本应用读取照片（系统可能把它归在「图片和视频」权限里）。");
        tips.setTextSize(12);
        tips.setTextColor(0xFF6B7482);
        tips.setPadding(0, dp(18), 0, 0);
        root.addView(tips);

        // 内容较多，放进可滚动容器，避免底部按钮看不到
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFFF6F7FB);
        scroll.addView(root, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
    }

    private void sendAction(String action) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先授予悬浮窗权限", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent svc = new Intent(this, PinService.class);
        svc.setAction(action);
        startServiceCompat(svc);
    }

    /** 引导用户把「截图贴图」加到下拉状态栏快捷开关 */
    private void addQuickTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            android.app.StatusBarManager sbm = getSystemService(android.app.StatusBarManager.class);
            if (sbm != null) {
                sbm.requestAddTileService(
                        new android.content.ComponentName(this, ScreenshotTileService.class),
                        "截图贴图", android.graphics.drawable.Icon.createWithResource(
                                this, R.mipmap.ic_launcher),
                        getMainExecutor(),
                        new java.util.function.Consumer<Integer>() {
                            @Override
                            public void accept(Integer result) {
                                Toast.makeText(MainActivity.this,
                                        result == android.app.StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED
                                                ? "已添加到状态栏快捷开关"
                                                : "请手动在状态栏编辑里添加「截图贴图」",
                                        Toast.LENGTH_LONG).show();
                            }
                        });
                return;
            }
        }
        Toast.makeText(this, "请下拉状态栏 → 点编辑按钮 → 把「截图贴图」拖进快捷开关",
                Toast.LENGTH_LONG).show();
    }

    private void startServiceCompat(Intent svc) {
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
    }

    private void ensurePermissions() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
            }
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_MEDIA);
            }
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_MEDIA);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2001 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先授予悬浮窗权限", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent svc = new Intent(this, PinService.class);
            svc.setAction(PinService.ACTION_PIN_URI);
            svc.setData(data.getData());
            startServiceCompat(svc);
        }
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    private TextView button(String text, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setAllCaps(false);
        btn.setTextSize(15);
        btn.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        lp.topMargin = dp(10);
        btn.setLayoutParams(lp);
        return btn;
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(4);
        return lp;
    }

    private android.graphics.drawable.GradientDrawable roundedColor(int color, int radiusDp) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }
}
