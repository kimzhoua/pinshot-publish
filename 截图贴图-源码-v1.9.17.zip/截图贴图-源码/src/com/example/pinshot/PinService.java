package com.example.pinshot;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentResolver;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.provider.MediaStore;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * 贴图窗口服务：负责把截图作为悬浮窗口钉在屏幕上。
 *
 * 交互：
 * 交互：单指拖动；双指捏合缩放；长按＝切换半透明；双击＝关闭这张贴图。
 */
public class PinService extends Service {

    /** 兼容旧版本调用，已不再显示悬浮球 */
    static final String ACTION_START = "action_start";
    static final String ACTION_STOP = "action_stop";
    static final String ACTION_PIN_LATEST = "action_pin_latest";
    static final String ACTION_PIN_URI = "action_pin_uri";
    static final String ACTION_CLEAR = "action_clear";
    static final String ACTION_RESTYLE = "action_restyle";
    static final String ACTION_PIN_PATH = "action_pin_path";
    static final String EXTRA_PATH = "extra_path";
    static final String EXTRA_X = "extra_x";
    static final String EXTRA_Y = "extra_y";
    static final String EXTRA_W = "extra_w";
    static final String EXTRA_H = "extra_h";

    private static final String CHANNEL_ID = "pinshot_service";
    private static final int NOTIFY_ID = 1024;

    private WindowManager wm;
    private final List<PinWindow> pins = new ArrayList<>();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private int screenW, screenH;

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        DisplayMetrics dm = getResources().getDisplayMetrics();
        screenW = dm.widthPixels;
        screenH = dm.heightPixels;
        startForegroundSafe();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent == null ? ACTION_PIN_LATEST : intent.getAction();
        if (action == null) action = ACTION_PIN_LATEST;

        switch (action) {
            case ACTION_PIN_LATEST:
                pinLatest();
                break;
            case ACTION_PIN_URI:
                if (intent != null && intent.getData() != null) {
                    addPin(intent.getData());
                }
                break;
            case ACTION_PIN_PATH:
                if (intent != null) {
                    String path = intent.getStringExtra(EXTRA_PATH);
                    if (path != null) {
                        Bitmap bmp = BitmapFactory.decodeFile(path);
                        if (bmp != null) {
                            int x = intent.getIntExtra(EXTRA_X, -1);
                            int y = intent.getIntExtra(EXTRA_Y, -1);
                            int w = intent.getIntExtra(EXTRA_W, 0);
                            int h = intent.getIntExtra(EXTRA_H, 0);
                            addPinBitmapAt(bmp, x, y, w, h);
                        }
                    }
                }
                break;
            case ACTION_CLEAR:
                clearPins();
                break;
            case ACTION_RESTYLE:
                refreshPinStyles();
                break;
            case ACTION_STOP:
                stopEverything();
                return START_NOT_STICKY;
            default:
                break;
        }
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onDestroy() {
        clearPins();
        super.onDestroy();
    }

    // ---------------- 前台通知 ----------------

    private void startForegroundSafe() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26 && nm != null) {
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, "贴图窗口", NotificationManager.IMPORTANCE_MIN);
            ch.setDescription("保持贴图窗口显示");
            nm.createNotificationChannel(ch);
        }

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent content = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Intent stop = new Intent(this, PinService.class).setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 1, stop,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL_ID)
                : new Notification.Builder(this);
        b.setContentTitle("截图贴图运行中")
                .setContentText("贴图窗口正在显示，点「关闭」可全部收起")
                .setSmallIcon(android.R.drawable.ic_menu_gallery)
                .setContentIntent(content)
                .setOngoing(true)
                .addAction(new Notification.Action.Builder(null, "关闭", stopPi).build());

        startForeground(NOTIFY_ID, b.build());
    }

    // ----------------
    // ---------------- 找最新截图 ----------------

    private Uri latestScreenshot() {
        ContentResolver cr = getContentResolver();
        Uri collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] proj = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.DATE_ADDED
        };

        // 先只在截图目录里找
        String where = null;
        String[] args = null;
        if (Build.VERSION.SDK_INT >= 29) {
            where = MediaStore.Images.Media.RELATIVE_PATH + " LIKE ?";
            args = new String[]{"%Screenshots%"};
        }

        Cursor c = null;
        try {
            c = cr.query(collection, proj, where, args,
                    MediaStore.Images.Media.DATE_ADDED + " DESC");
            if (c == null || !c.moveToFirst()) {
                if (c != null) c.close();
                c = cr.query(collection, proj, null, null,
                        MediaStore.Images.Media.DATE_ADDED + " DESC");
            }
            if (c != null && c.moveToFirst()) {
                long id = c.getLong(0);
                return Uri.withAppendedPath(collection, String.valueOf(id));
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return null;
    }

    private void pinLatest() {
        Uri uri = latestScreenshot();
        if (uri == null) {
            toast("没找到图片，请先给「截图贴图」读取照片权限");
            return;
        }
        addPin(uri);
    }

    // ---------------- 贴图窗口 ----------------

    private void addPin(Uri uri) {
        Bitmap bmp = decode(uri);
        if (bmp == null) {
            toast("图片读取失败");
            return;
        }
        addPinBitmap(bmp);
    }

    private void addPinBitmap(Bitmap bmp) {
        addPinBitmapAt(bmp, -1, -1, 0, 0);
    }

    /** exactX/Y/W/H 均为屏幕像素；传 -1 表示按分辨率+居中错开的方式摆放 */
    private void addPinBitmapAt(Bitmap bmp, int exactX, int exactY, int exactW, int exactH) {
        if (bmp == null) {
            toast("图片读取失败");
            return;
        }

        PinWindow pw = new PinWindow();
        pw.bitmap = bmp;

        FrameLayout container = new FrameLayout(this);
        applyFrameStyle(container);

        ImageView iv = new ImageView(this);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setImageBitmap(bmp);
        FrameLayout.LayoutParams ilp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        ilp.setMargins(dp(2), dp(2), dp(2), dp(2));
        container.addView(iv, ilp);

        // 初始大小按截图自身分辨率来：1 个图片像素 ≈ 1 个屏幕像素
        int nativeW = bmp.getWidth();
        int nativeH = bmp.getHeight();
        int w = nativeW;
        int h = nativeH;
        if (exactW > 0 && exactH > 0) {
            w = exactW;
            h = exactH;
        }
        int maxW = screenW;
        int maxH = screenH;
        if (exactW <= 0 && w > maxW) {
            // 超过屏幕宽度：等比缩到屏幕宽度
            h = (int) (h * (float) maxW / Math.max(1, w));
            w = maxW;
        } else if (exactW <= 0 && w < dp(72) && getSharedPreferences(MainActivity.PREF, MODE_PRIVATE)
                .getBoolean("upscale_small", true)) {
            // 小截图（小弹窗/图标）：按设置决定是否放大到至少 72dp 宽
            h = (int) (h * (float) dp(72) / Math.max(1, w));
            w = dp(72);
        }
        if (exactW <= 0 && h > maxH) {
            w = (int) (w * (float) maxH / Math.max(1, h));
            h = maxH;
        }

        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE;
        if (exactX >= 0) {
            // 原位置贴图：坐标按整块屏幕计算，覆盖状态栏区域
            flags |= WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN;
        }
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(w, h,
                Build.VERSION.SDK_INT >= 26
                        ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                        : WindowManager.LayoutParams.TYPE_PHONE,
                flags,
                android.graphics.PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (exactX >= 0) {
            lp.x = exactX;
            lp.y = exactY;
        } else {
            int cascade = Math.min(pins.size(), 6) * dp(18);
            // 满屏贴图时贴左上角，保证整张图完整可见
            int x = (screenW - w) / 2 + cascade;
            int y = screenH / 5 + cascade;
            x = Math.max(0, Math.min(Math.max(0, screenW - w), x));
            y = Math.max(0, Math.min(Math.max(0, screenH - h), y));
            lp.x = x;
            lp.y = y;
        }

        pw.container = container;
        pw.lp = lp;

        container.setOnTouchListener(new PinTouch(this, pw, wm, screenW, screenH,
                new Runnable() {
                    @Override
                    public void run() {
                        removePin(pw);
                    }
                }));

        // 原位置贴图：去掉白底/描边/内边距，保证和原界面像素对齐
        if (exactX >= 0) {
            container.setBackground(null);
            container.setElevation(0);
            ViewGroup.LayoutParams params = iv.getLayoutParams();
            if (params instanceof FrameLayout.LayoutParams) {
                ((FrameLayout.LayoutParams) params).setMargins(0, 0, 0, 0);
                iv.setLayoutParams(params);
            }
        }

        try {
            wm.addView(container, lp);
            pins.add(pw);
        } catch (Exception e) {
            toast("贴图失败：" + e.getMessage());
        }
    }

    /** 按设置决定贴图是否显示白底边框与阴影 */
    private void applyFrameStyle(FrameLayout container) {
        boolean frameOn = getSharedPreferences(MainActivity.PREF, MODE_PRIVATE)
                .getBoolean("frame_on", true);
        if (frameOn) {
            GradientDrawable frame = new GradientDrawable();
            frame.setColor(0xFFFFFFFF);
            frame.setCornerRadius(dp(10));
            frame.setStroke(dp(1), 0x33000000);
            container.setBackground(frame);
            container.setElevation(dp(12));
        } else {
            container.setBackground(null);
            container.setElevation(0);
        }
    }

    /** 设置开关变化后，让屏幕上的贴图立刻跟着换样式 */
    private void refreshPinStyles() {
        for (PinWindow pw : pins) {
            if (pw.container != null) applyFrameStyle(pw.container);
        }
    }

    private void removePin(PinWindow pw) {
        try {
            wm.removeView(pw.container);
        } catch (Exception ignored) {
        }
        pins.remove(pw);
        if (pw.bitmap != null) pw.bitmap.recycle();
    }

    private void clearPins() {
        for (PinWindow pw : new ArrayList<>(pins)) {
            removePin(pw);
        }
        pins.clear();
    }

    private void stopEverything() {
        clearPins();
        stopForegroundCompat();
        stopSelf();
    }

    private void stopForegroundCompat() {
        if (Build.VERSION.SDK_INT >= 24) {
            stopForeground(true);
        } else {
            stopForeground(true);
        }
    }

    // ---------------- 工具 ----------------

    private Bitmap decode(Uri uri) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            int target = Math.max(720, screenW);
            int sample = 1;
            while (bounds.outWidth / (sample * 2) >= target) sample *= 2;

            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            opts.inPreferredConfig = Bitmap.Config.ARGB_8888;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                return BitmapFactory.decodeStream(in, null, opts);
            }
        } catch (Exception e) {
            return null;
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private int clamp(int v, int min, int max) {
        return Math.max(min, Math.min(max, v));
    }

    /** 一个贴图窗口的状态 */
    static class PinWindow {
        FrameLayout container;
        WindowManager.LayoutParams lp;
        Bitmap bitmap;
        float alpha = 1f;
    }
}
