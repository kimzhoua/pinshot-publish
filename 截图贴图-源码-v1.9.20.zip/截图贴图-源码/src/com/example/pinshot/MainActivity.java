package com.example.pinshot;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 截图贴图 · 主界面
 *
 * 用法：先授予「悬浮窗」权限 → 截图后点「钉住最新截图」，或在最近截图里挑一张贴到屏幕上。
 */
public class MainActivity extends Activity {

    static final String PREF = "pinshot";
    private static final int REQ_MEDIA = 1001;
    private static final int REQ_NOTIFY = 1002;

    private TextView statusText;
    private OtaManager otaManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        otaManager = new OtaManager(this);
        buildUi();
    }

    @Override
    protected void onDestroy() {
        if (otaManager != null) otaManager.release();
        super.onDestroy();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshState();
    }

    private void refreshState() {
        boolean overlayOk = Settings.canDrawOverlays(this);
        statusText.setText(overlayOk
                ? "权限已就绪：截图后点「钉住最新截图」或从最近截图里选一张即可贴到屏幕上"
                : "还差一步：需要授予「显示在其他应用上层」权限");
        statusText.setTextColor(overlayOk ? 0xFF1F7A3D : 0xFFC62828);
    }

    /** 沉浸式状态栏：内容延伸到状态栏下方，状态栏透明、图标深色 */
    private void applyImmersiveStatusBar() {
        android.view.Window w = getWindow();
        w.addFlags(android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.clearFlags(android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        w.setStatusBarColor(0x00000000);
        if (Build.VERSION.SDK_INT >= 26) {
            w.setNavigationBarColor(0x00000000);
        }
        int flags = android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                | android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        if (Build.VERSION.SDK_INT >= 26) {
            flags |= android.view.View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR;
        }
        w.getDecorView().setSystemUiVisibility(flags);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private void buildUi() {
        applyImmersiveStatusBar();
        android.widget.ScrollView scrollRoot = new android.widget.ScrollView(this);
        scrollRoot.setBackgroundColor(0xFFF6F7FB);
        scrollRoot.setFillViewport(true);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFFF6F7FB);
        int pad = dp(20);
        root.setPadding(pad, statusBarHeight() + dp(16), pad, dp(32));

        LinearLayout titleRow = new LinearLayout(this);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("截图贴图");
        title.setTextSize(24);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFF1B2230);
        title.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        titleRow.addView(title);

        android.widget.ImageView gear = new android.widget.ImageView(this);
        gear.setImageResource(R.drawable.ic_settings_gear);
        gear.setScaleType(android.widget.ImageView.ScaleType.CENTER_INSIDE);
        int gearSize = dp(38);
        gear.setLayoutParams(new LinearLayout.LayoutParams(gearSize, gearSize));
        gear.setBackground(roundedColor(0xFFFFFFFF, 12));
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSettings();
            }
        });
        titleRow.addView(gear);
        root.addView(titleRow);

        TextView sub = new TextView(this);
        sub.setText("把截图钉在屏幕上，随时对照、复制、核对内容");
        sub.setTextSize(13);
        sub.setTextColor(0xFF6B7482);
        sub.setPadding(0, dp(6), 0, dp(16));
        root.addView(sub);

        statusText = new TextView(this);
        statusText.setTextSize(14);
        statusText.setPadding(dp(14), dp(14), dp(14), dp(14));
        statusText.setBackground(roundedColor(0xFFFFFFFF, 14));
        root.addView(statusText, matchWrap());

        // ---------- 主操作：只保留最常用的两个 ----------
        LinearLayout primaryCard = new LinearLayout(this);
        primaryCard.setOrientation(LinearLayout.VERTICAL);
        primaryCard.setPadding(dp(18), dp(18), dp(18), dp(18));
        LinearLayout.LayoutParams pcLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        pcLp.topMargin = dp(16);
        primaryCard.setLayoutParams(pcLp);
        primaryCard.setBackground(roundedColor(0xFFFFFFFF, 18));

        TextView pinBtn = new TextView(this);
        pinBtn.setText("钉住最新截图");
        pinBtn.setTextSize(17);
        pinBtn.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        pinBtn.setTextColor(0xFFFFFFFF);
        pinBtn.setGravity(Gravity.CENTER);
        pinBtn.setBackground(roundedColor(0xFF2F6BFF, 14));
        pinBtn.setLayoutParams(new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54)));
        pinBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendAction(PinService.ACTION_PIN_LATEST);
            }
        });
        primaryCard.addView(pinBtn);

        TextView pickBtn = new TextView(this);
        pickBtn.setText("从最近截图里选一张贴图");
        pickBtn.setTextSize(16);
        pickBtn.setTextColor(0xFF1B2230);
        android.graphics.drawable.GradientDrawable pickBg = roundedColor(0xFFF5F7FC, 14);
        pickBg.setStroke(dp(1), 0xFFE3E8F2);
        pickBtn.setBackground(pickBg);
        pickBtn.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams pickLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(54));
        pickLp.topMargin = dp(12);
        pickBtn.setLayoutParams(pickLp);
        pickBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ScreenshotPickerActivity.class));
            }
        });
        primaryCard.addView(pickBtn);

        TextView clearBtn = new TextView(this);
        clearBtn.setText("关闭屏幕上所有贴图");
        clearBtn.setTextSize(16);
        clearBtn.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        clearBtn.setTextColor(0xFFE0455E);
        clearBtn.setGravity(Gravity.CENTER);
        android.graphics.drawable.GradientDrawable clearBg = roundedColor(0xFFFFEFF1, 14);
        clearBg.setStroke(dp(1), 0xFFF7C8CF);
        clearBtn.setBackground(clearBg);
        LinearLayout.LayoutParams clearLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(48));
        clearLp.topMargin = dp(10);
        clearBtn.setLayoutParams(clearLp);
        clearBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendAction(PinService.ACTION_CLEAR);
            }
        });
        primaryCard.addView(clearBtn);
        root.addView(primaryCard);


        TextView tips = new TextView(this);
        tips.setText("贴图后可单指拖动、双指缩放、长按半透明、双击关闭");
        tips.setTextSize(12);
        tips.setTextColor(0xFF6B7482);
        tips.setPadding(0, dp(18), 0, 0);
        root.addView(tips);

        // 内容较多，放进可滚动容器，避免底部按钮看不到
        android.widget.ScrollView scroll = new android.widget.ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFFF6F7FB);
        scroll.addView(root, new android.widget.FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);
    }

    private void sendAction(String action) {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先授予悬浮窗权限", Toast.LENGTH_SHORT).show();
            return;
        }
        Intent svc = new Intent(this, PinService.class);
        svc.setAction(action);
        startServiceCompat(svc);
    }

    // ============ 设置面板 ============

    private void showSettings() {
        final android.app.Dialog dialog = new android.app.Dialog(this);
        dialog.requestWindowFeature(android.view.Window.FEATURE_NO_TITLE);

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundedColor(0xFFFFFFFF, 24));

        // ---- 头部 ----
        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(dp(22), dp(20), dp(22), dp(6));

        TextView title = new TextView(this);
        title.setText("设置");
        title.setTextSize(19);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setTextColor(0xFF1B2230);
        header.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("截图贴图 v" + versionName() + " · " + versionCode());
        subtitle.setTextSize(11);
        subtitle.setTextColor(0xFF98A0AE);
        subtitle.setPadding(0, dp(4), 0, 0);
        header.addView(subtitle);
        card.addView(header);

        // ---- 内容（可滚动）----
        LinearLayout body = new LinearLayout(this);
        body.setOrientation(LinearLayout.VERTICAL);
        body.setPadding(dp(18), dp(4), dp(18), dp(4));

        body.addView(groupLabel("权限"));
        body.addView(group(
                actionItem("悬浮窗权限", overlayHint(), null,
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                if (!Settings.canDrawOverlays(MainActivity.this)) {
                                    startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                            Uri.parse("package:" + getPackageName())));
                                } else {
                                    Toast.makeText(MainActivity.this, "已授予，无需重复授权",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        })
        ));

        body.addView(groupLabel("快捷操作"));
        body.addView(group(
                actionItem("添加到状态栏快捷开关", "下拉栏一键截屏", null,
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                addQuickTile();
                            }
                        }),
                actionItem("从相册选一张图贴图", null, null,
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Intent pick = new Intent(Intent.ACTION_GET_CONTENT);
                                pick.setType("image/*");
                                pick.addCategory(Intent.CATEGORY_OPENABLE);
                                startActivityForResult(pick, 2001);
                            }
                        })
        ));

        body.addView(groupLabel("贴图外观"));
        body.addView(group(
                switchItem("显示边框与阴影", "frame_on", true, new Runnable() {
                    @Override
                    public void run() {
                        if (Settings.canDrawOverlays(MainActivity.this)) {
                            sendAction(PinService.ACTION_RESTYLE);
                        }
                    }
                }),
                switchItem("小截图放大显示", "upscale_small", true, null)
        ));

        body.addView(groupLabel("关于"));
        body.addView(group(
                actionItem("检查应用更新", "当前 v" + versionName(), "检查",
                        new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                otaManager.checkUpdate(true);
                            }
                        })
        ));

        android.widget.ScrollView sc = new android.widget.ScrollView(this);
        sc.setFillViewport(false);
        sc.addView(body, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        card.addView(sc, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        // ---- 底部完成 ----
        TextView done = new TextView(this);
        done.setText("完成");
        done.setTextSize(15);
        done.setTextColor(0xFF2F6BFF);
        done.setGravity(Gravity.CENTER);
        done.setBackground(roundedColor(0xFFF1F5FF, 14));
        LinearLayout.LayoutParams doneLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(50));
        doneLp.setMargins(dp(18), dp(8), dp(18), dp(18));
        done.setLayoutParams(doneLp);
        done.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.dismiss();
                refreshState();
            }
        });
        card.addView(done);

        dialog.setContentView(card);
        android.view.Window w = dialog.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(0x00000000));
            int width = getResources().getDisplayMetrics().widthPixels - dp(32);
            w.setLayout(width, android.view.WindowManager.LayoutParams.WRAP_CONTENT);
        }
        dialog.show();
    }

    private String overlayHint() {
        return Settings.canDrawOverlays(this) ? "已授予" : "未授予，点此授权";
    }

    private TextView groupLabel(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(12);
        tv.setTextColor(0xFF98A0AE);
        tv.setPadding(dp(6), dp(16), dp(6), dp(8));
        return tv;
    }

    /** 一组设置：浅灰圆角卡片，内部条目自动加分隔线 */
    private View group(View... items) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackground(roundedColor(0xFFF6F7FB, 16));
        for (int k = 0; k < items.length; k++) {
            if (k > 0) {
                View line = new View(this);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, dp(1));
                lp.leftMargin = dp(14);
                lp.rightMargin = dp(14);
                line.setLayoutParams(lp);
                line.setBackgroundColor(0xFFE9ECF3);
                card.addView(line);
            }
            card.addView(items[k]);
        }
        return card;
    }

    /** 条目：左标题/副标题，右侧动作文字，整行可点 */
    private View actionItem(String label, String sub, String action, View.OnClickListener l) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(13), dp(14), dp(13));
        row.setOnClickListener(l);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        texts.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(14);
        tv.setTextColor(0xFF1B2230);
        texts.addView(tv);

        if (sub != null && sub.length() > 0) {
            TextView sv = new TextView(this);
            sv.setText(sub);
            sv.setTextSize(11);
            sv.setTextColor(0xFF98A0AE);
            sv.setPadding(0, dp(3), 0, 0);
            texts.addView(sv);
        }
        row.addView(texts);

        TextView right = new TextView(this);
        right.setText(action == null ? "›" : action);
        right.setTextSize(13);
        right.setTextColor(action == null ? 0xFFC3C9D6 : 0xFF2F6BFF);
        row.addView(right);
        return row;
    }

    /** 条目：左标题（可带副标题），右侧开关 */
    private View switchItem(String label, final String key, boolean def, final Runnable after) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(dp(14), dp(8), dp(10), dp(8));

        TextView tv = new TextView(this);
        tv.setText(label);
        tv.setTextSize(14);
        tv.setTextColor(0xFF1B2230);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        row.addView(tv);

        android.widget.Switch sw = new android.widget.Switch(this);
        sw.setChecked(getSharedPreferences(PREF, MODE_PRIVATE).getBoolean(key, def));
        sw.setOnCheckedChangeListener(new android.widget.CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(android.widget.CompoundButton b, boolean checked) {
                getSharedPreferences(PREF, MODE_PRIVATE).edit().putBoolean(key, checked).apply();
                if (after != null) after.run();
            }
        });
        row.addView(sw);
        return row;
    }

    /** 引导用户把「截图贴图」加到下拉状态栏快捷开关 */
    private void addQuickTile() {
        if (Build.VERSION.SDK_INT >= 33) {
            android.app.StatusBarManager sbm = getSystemService(android.app.StatusBarManager.class);
            if (sbm != null) {
                sbm.requestAddTileService(
                        new android.content.ComponentName(this, ScreenshotTileService.class),
                        "截图贴图", android.graphics.drawable.Icon.createWithResource(
                                this, R.drawable.ic_tile),
                        getMainExecutor(),
                        new java.util.function.Consumer<Integer>() {
                            @Override
                            public void accept(Integer result) {
                                Toast.makeText(MainActivity.this,
                                        result == android.app.StatusBarManager.TILE_ADD_REQUEST_RESULT_TILE_ADDED
                                                ? "已添加到状态栏快捷开关"
                                                : "请手动在状态栏编辑里添加「截图贴图」",
                                        Toast.LENGTH_LONG).show();
                            }
                        });
                return;
            }
        }
        Toast.makeText(this, "请下拉状态栏 → 点编辑按钮 → 把「截图贴图」拖进快捷开关",
                Toast.LENGTH_LONG).show();
    }

    private void startServiceCompat(Intent svc) {
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
    }

    private void ensurePermissions() {
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFY);
            }
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, REQ_MEDIA);
            }
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, REQ_MEDIA);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 2001 && resultCode == RESULT_OK && data != null && data.getData() != null) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "请先授予悬浮窗权限", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent svc = new Intent(this, PinService.class);
            svc.setAction(PinService.ACTION_PIN_URI);
            svc.setData(data.getData());
            svc.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startServiceCompat(svc);
        }
    }

    private int versionCode() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    private TextView button(String text, View.OnClickListener listener) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setAllCaps(false);
        btn.setTextSize(15);
        btn.setOnClickListener(listener);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, dp(52));
        lp.topMargin = dp(10);
        btn.setLayoutParams(lp);
        return btn;
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = dp(4);
        return lp;
    }

    private android.graphics.drawable.GradientDrawable roundedColor(int color, int radiusDp) {
        android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    @Override
    public void onBackPressed() {
        moveTaskToBack(true);
    }
}
