package com.example.pinshot;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

/**
 * 截图选择框：列出最近的截图，选中后可选「在当前位置贴图」或「保存到相册」。
 */
public class ScreenshotPickerActivity extends Activity {

    private static final int MAX_ITEMS = 60;
    private final List<Uri> items = new ArrayList<>();
    private LinearLayout grid;
    private int cellSize;
    /** true＝只看截图；false＝全部图片（含相机拍摄的照片） */
    private boolean onlyScreenshots = false;
    private TextView chipAll;
    private TextView chipShots;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        cellSize = Math.round(104 * getResources().getDisplayMetrics().density);
        buildUi();
        updateChips();
        loadImages();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF101319);
        root.setPadding(dp(16), dp(24), dp(16), dp(8));

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);

        TextView title = new TextView(this);
        title.setText("选择图片贴图");
        title.setTextSize(18);
        title.setTextColor(Color.WHITE);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        title.setLayoutParams(new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(title);

        TextView close = new TextView(this);
        close.setText("关闭");
        close.setTextSize(14);
        close.setTextColor(0xFF9AA4B5);
        close.setPadding(dp(10), dp(6), dp(2), dp(6));
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        head.addView(close);
        root.addView(head);

        TextView hint = new TextView(this);
        hint.setText("点一张图直接贴到屏幕上；长按可保存到相册");
        hint.setTextSize(12);
        hint.setTextColor(0xFF7C8698);
        hint.setPadding(0, dp(4), 0, dp(10));
        root.addView(hint);

        // 筛选：全部图片 / 仅截图
        LinearLayout chips = new LinearLayout(this);
        chips.setOrientation(LinearLayout.HORIZONTAL);
        chips.setPadding(0, 0, 0, dp(8));

        chipAll = makeChip("全部图片", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onlyScreenshots = false;
                updateChips();
                loadImages();
            }
        });
        chipShots = makeChip("仅截图", new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onlyScreenshots = true;
                updateChips();
                loadImages();
            }
        });
        chips.addView(chipAll);
        LinearLayout.LayoutParams chipLp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        chipLp.leftMargin = dp(8);
        chips.addView(chipShots, chipLp);
        root.addView(chips);

        ScrollView scroll = new ScrollView(this);
        grid = new LinearLayout(this);
        grid.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(grid);
        root.addView(scroll, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
    }

    // ---------------- 数据 ----------------

    private void loadImages() {
        items.clear();
        grid.removeAllViews();
        ContentResolver cr = getContentResolver();
        Uri collection = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
        String[] proj = {MediaStore.Images.Media._ID, MediaStore.Images.Media.DATE_ADDED};

        String where = null;
        String[] args = null;
        if (onlyScreenshots && Build.VERSION.SDK_INT >= 29) {
            where = MediaStore.Images.Media.RELATIVE_PATH + " LIKE ?";
            args = new String[]{"%Screenshot%"};
        }

        Cursor c = null;
        try {
            c = cr.query(collection, proj, where, args,
                    MediaStore.Images.Media.DATE_ADDED + " DESC");
            readCursor(c);
            if (items.isEmpty() && c != null) {
                c.close();
                c = null;
                // 没有匹配项时退一步：给全部最近图片，避免一片空白
                c = cr.query(collection, proj, null, null,
                        MediaStore.Images.Media.DATE_ADDED + " DESC");
                readCursor(c);
            }
        } catch (Exception e) {
            toast("读取图片失败：" + e.getMessage());
        } finally {
            if (c != null) c.close();
        }

        if (items.isEmpty()) {
            TextView empty = new TextView(this);
            empty.setText(onlyScreenshots
                    ? "没有找到截图。\n换成「全部图片」看看，或允许本应用读取照片。"
                    : "没有找到图片。\n请允许本应用读取照片（系统可能把它归在「图片和视频」权限里）。");
            empty.setTextSize(13);
            empty.setTextColor(0xFF9AA4B5);
            empty.setPadding(dp(6), dp(20), dp(6), dp(6));
            grid.addView(empty);
            return;
        }
        renderGrid();
    }

    private TextView makeChip(String text, View.OnClickListener l) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTextSize(13);
        tv.setPadding(dp(14), dp(7), dp(14), dp(7));
        tv.setOnClickListener(l);
        return tv;
    }

    private void updateChips() {
        styleChip(chipAll, !onlyScreenshots);
        styleChip(chipShots, onlyScreenshots);
    }

    private void styleChip(TextView tv, boolean on) {
        tv.setTextColor(on ? 0xFFFFFFFF : 0xFF9AA4B5);
        tv.setBackground(rounded(on ? 0xFF2F6BFF : 0xFF1C2230, 14));
    }

    private void readCursor(Cursor c) {
        if (c == null) return;
        while (c.moveToNext() && items.size() < MAX_ITEMS) {
            long id = c.getLong(0);
            items.add(Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    String.valueOf(id)));
        }
    }

    private void renderGrid() {
        grid.removeAllViews();
        LinearLayout row = null;
        for (int i = 0; i < items.size(); i++) {
            if (i % 3 == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                rlp.topMargin = dp(6);
                row.setLayoutParams(rlp);
                grid.addView(row);
            }
            row.addView(makeCell(items.get(i)));
        }
    }

    private View makeCell(final Uri uri) {
        ImageView iv = new ImageView(this);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(cellSize, cellSize);
        lp.setMargins(dp(5), 0, dp(5), 0);
        iv.setLayoutParams(lp);
        iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        iv.setBackground(rounded(0xFF1C2230, 12));
        iv.setClipToOutline(false);

        final ImageView target = iv;
        new Thread(new Runnable() {
            @Override
            public void run() {
                final Bitmap bmp = loadThumb(uri, cellSize);
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (bmp != null) target.setImageBitmap(bmp);
                    }
                });
            }
        }).start();

        // 点图片＝直接贴图；长按＝保存到相册
        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pinHere(uri);
            }
        });
        iv.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                saveToAlbum(uri);
                return true;
            }
        });
        return iv;
    }

    private Bitmap loadThumb(Uri uri, int size) {
        try {
            BitmapFactory.Options bounds = new BitmapFactory.Options();
            bounds.inJustDecodeBounds = true;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                BitmapFactory.decodeStream(in, null, bounds);
            }
            int sample = 1;
            while (bounds.outWidth / (sample * 2) >= size) sample *= 2;

            BitmapFactory.Options opts = new BitmapFactory.Options();
            opts.inSampleSize = sample;
            try (InputStream in = getContentResolver().openInputStream(uri)) {
                return BitmapFactory.decodeStream(in, null, opts);
            }
        } catch (Exception e) {
            return null;
        }
    }

    // ---------------- 动作 ----------------

    private void pinHere(Uri uri) {
        if (!Settings.canDrawOverlays(this)) {
            toast("需要「显示在其他应用上层」权限，去设置里打开");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        Intent svc = new Intent(this, PinService.class);
        svc.setAction(PinService.ACTION_PIN_URI);
        svc.setData(uri);
        if (Build.VERSION.SDK_INT >= 26) {
            startForegroundService(svc);
        } else {
            startService(svc);
        }
        toast("已贴到屏幕上");
        finish();
    }

    private void saveToAlbum(Uri uri) {
        try {
            String name = "截图贴图_" + System.currentTimeMillis() + ".png";
            Uri target;
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH,
                        Environment.DIRECTORY_PICTURES + "/截图贴图");
                target = getContentResolver()
                        .insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (target == null) {
                    toast("保存失败");
                    return;
                }
                try (InputStream in = getContentResolver().openInputStream(uri);
                     OutputStream out = getContentResolver().openOutputStream(target)) {
                    if (in == null || out == null) {
                        toast("保存失败");
                        return;
                    }
                    byte[] buf = new byte[8192];
                    int len;
                    while ((len = in.read(buf)) > 0) out.write(buf, 0, len);
                }
                toast("已保存到相册：Pictures/截图贴图");
            } else {
                Bitmap bmp = loadThumb(uri, 2000);
                if (bmp == null) {
                    toast("保存失败");
                    return;
                }
                MediaStore.Images.Media.insertImage(getContentResolver(), bmp, name,
                        "截图贴图导出");
                toast("已保存到相册");
            }
        } catch (Exception e) {
            toast("保存失败：" + e.getMessage());
        }
    }

    // ---------------- 工具 ----------------

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radiusDp));
        return d;
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
